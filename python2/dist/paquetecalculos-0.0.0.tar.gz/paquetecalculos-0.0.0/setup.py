from setuptools import setup
setup(
      name="paquetecalculos"
      
)